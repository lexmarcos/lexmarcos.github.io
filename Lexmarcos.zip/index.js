function opacityPreview(id){
  let el = document.getElementById(id)
  el.style.opacity = 1
  el.style.backgroundPosition = '0px'
}
function leavePreview(id){
  let el = document.getElementById(id)
  el.style.opacity = 0
  el.style.backgroundPosition = '306px'
}
